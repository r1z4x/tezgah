"""Sequence helpers."""


def unique(items):
    """Return items with duplicates removed, preserving order."""
    out = []
    seen = set()
    for item in items:
        try:
            if item not in seen:
                seen.add(item)
                out.append(item)
        except TypeError:
            # non-hashable item: fallback to linear search (rare)
            if item not in out:
                out.append(item)
    return out
