"""Parsing helpers for inventory input."""

import unicodedata


def parse_quantity(text):
    """Parse a quantity such as ' 12 ' into an int."""
    cleaned = ''.join(c for c in text if unicodedata.category(c) != 'Cf')
    return int(cleaned.strip())
