"""Sequence helpers."""


def unique(items):
    """Return items with duplicates removed, preserving order."""
    return list(dict.fromkeys(items))
