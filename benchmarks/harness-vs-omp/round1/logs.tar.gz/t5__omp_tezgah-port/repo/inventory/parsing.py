"""Parsing helpers for inventory input."""

import re

# Match invisible/format characters that survive str.strip().
# This covers:
#   Cf (format): zero-width space U+200B, ZWNJ U+200C, ZWJ U+200D,
#                LRM/RLM U+200E/U+200F, BOM U+FEFF, bidi controls U+202A–U+202E,
#                word joiner U+2060, Arabic/Syriac format chars, etc.
#   Cc (control): ASCII control (\x00–\x1f except tab/newline which strip()
#                 handles on edges), C1 controls (\x7f–\x9f)
#   Soft hyphen (\u00ad): category Pd but never visible
_INVISIBLE_RE = re.compile(
    '['
    '\u0000-\u000d'                                   # all Cc including \t\n\r
    '\u007f-\u009f'                               # C1 controls
    '\u00ad'                                      # soft hyphen
    '\u0600-\u0605\u061c\u06dd\u070f\u0890\u0891\u08e2'  # Arabic/Syriac format
    '\u180b-\u180e'                               # Mongolian format
    '\u200b-\u200f\u202a-\u202e'                   # ZW* + bidi controls
    '\u2060-\u2069'                               # word joiner → bidi isolates
    '\ufdd0-\ufdef'                               # noncharacters
    '\ufeff'                                      # BOM
    '\ufff0-\ufff8'                               # specials
    '\U000e0001'                                  # language tag
    '\U000e0020-\U000e007f'                       # tag chars
    '\U000e0100-\U000e01ef'                       # variation selectors supplement
    ']'
)


def sanitize_numeric(text):
    """Remove invisible/format characters that survive str.strip() from numeric input."""
    return _INVISIBLE_RE.sub('', text).strip()


def parse_quantity(text):
    """Parse a quantity such as ' 12 ' into an int.

    Strips invisible Unicode characters (zero-width space, BOM, etc.)
    that commonly arrive via copy-paste.
    """
    return int(sanitize_numeric(text))
