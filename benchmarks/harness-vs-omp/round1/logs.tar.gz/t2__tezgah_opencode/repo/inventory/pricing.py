"""Pricing helpers."""

BULK_DISCOUNT_PCT = 5


def line_total(item):
    """Return the price for one item line (quantity * unit price)."""
    return round(item["quantity"] * item["unit_price"], 2)


def total_with_tax(items, rate):
    if rate < 0:
        raise ValueError("rate must be non-negative")
    total = sum(item["price"] for item in items)
    return round(total + total * rate, 2)
