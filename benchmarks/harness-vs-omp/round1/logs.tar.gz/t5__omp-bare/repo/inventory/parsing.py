"""Parsing helpers for inventory input."""

import unicodedata


def _strip_invisible(text):
    """Strip leading/trailing invisible Unicode characters.

    str.strip() removes Unicode whitespace (Zs, Zl, Zp categories) but
    does NOT remove format characters (Cf) such as zero-width space
    (U+200B), BOM (U+FEFF), zero-width joiners, or soft hyphen.
    These end up in copy-pasted numeric input and crash int()/float().
    """
    text = text.strip()
    # skip leading invisible format/control chars
    start = 0
    while start < len(text) and unicodedata.category(text[start]) in ('Cf', 'Cc'):
        start += 1
    if start == len(text):
        return ''
    # skip trailing invisible format/control chars
    end = len(text)
    while end > start and unicodedata.category(text[end - 1]) in ('Cf', 'Cc'):
        end -= 1
    return text[start:end]


def parse_quantity(text):
    """Parse a quantity such as ' 12 ' into an int.

    Invisible Unicode characters (zero-width space, BOM, etc.) that
    survive str.strip() are stripped before conversion.
    """
    return int(_strip_invisible(text))
