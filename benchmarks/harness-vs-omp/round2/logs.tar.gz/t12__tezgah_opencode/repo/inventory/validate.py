"""Input validation for the inventory API."""

from inventory.errors import InventoryError


def load_items(raw):
    out = []
    for idx, entry in enumerate(raw):
        if not isinstance(entry, dict) or not isinstance(entry.get("name"), str):
            raise InventoryError(f"item {idx}: name required")
        price = entry.get("price")
        if not isinstance(price, (int, float)) or price <= 0:
            raise InventoryError(f"item {idx}: price must be positive")
        out.append({"name": entry["name"], "price": price})
    return out
